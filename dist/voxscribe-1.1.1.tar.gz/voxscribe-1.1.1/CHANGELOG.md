# Changelog

## 1.1.0 (2023-03-29)

#### New Features

* add functionality to get text from audio that is base64 encoded.


## v1.0.1 (2023-03-22)

#### Others

* build v1.0.1